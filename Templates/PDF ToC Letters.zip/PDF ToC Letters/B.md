---
loc: cplane/CP-RT/CP- RT/UT/services/cell_mgmt/system_information_assembler/
Tags:
---

<div style="page-break-after: always;"></div>

# `=this.file.name`

```dataviewjs
const currentFileName = dv.current().file.name.replace('.md', '');
const currentFolder = dv.current().file.folder;
const matchingFiles = dv.pages(`"${currentFolder}"`)
  .where(p => p.file.name.startsWith(currentFileName) && p.file.name !== dv.current().file.name)
  .map(p => p.file.link);

dv.list(matchingFiles);

```

